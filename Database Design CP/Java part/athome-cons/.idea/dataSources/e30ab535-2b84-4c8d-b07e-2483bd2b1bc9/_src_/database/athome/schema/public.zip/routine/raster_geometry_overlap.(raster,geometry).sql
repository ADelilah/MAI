CREATE FUNCTION raster_geometry_overlap (raster, geometry) RETURNS boolean
	LANGUAGE sql
AS $$
select $1::geometry OPERATOR(public.&&) $2
$$
