CREATE FUNCTION lockrow (text, text, text, text) RETURNS integer
	LANGUAGE sql
AS $$
 SELECT LockRow($1, $2, $3, $4, now()::timestamp+'1:00'); 
$$
