CREATE FUNCTION st_summarystats (rast raster, exclude_nodata_value boolean) RETURNS summarystats
	LANGUAGE sql
AS $$
 SELECT public._ST_summarystats($1, 1, $2, 1) 
$$
