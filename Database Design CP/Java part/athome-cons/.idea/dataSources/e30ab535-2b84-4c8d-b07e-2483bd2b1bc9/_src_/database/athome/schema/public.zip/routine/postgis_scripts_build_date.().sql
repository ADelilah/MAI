CREATE FUNCTION postgis_scripts_build_date () RETURNS text
	LANGUAGE sql
AS $$
SELECT '2016-11-16 12:21:43'::text AS version
$$
