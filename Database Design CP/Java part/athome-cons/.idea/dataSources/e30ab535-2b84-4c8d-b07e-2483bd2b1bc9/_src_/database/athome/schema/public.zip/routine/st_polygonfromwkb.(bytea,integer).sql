CREATE FUNCTION st_polygonfromwkb (bytea, integer) RETURNS geometry
	LANGUAGE sql
AS $$
	SELECT CASE WHEN public.geometrytype(public.ST_GeomFromWKB($1,$2)) = 'POLYGON'
	THEN public.ST_GeomFromWKB($1, $2)
	ELSE NULL END
	
$$
