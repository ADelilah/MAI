CREATE FUNCTION st_mapalgebrafct (rast raster, band integer, onerastuserfunc regprocedure) RETURNS raster
	LANGUAGE sql
AS $$
 SELECT public.ST_mapalgebrafct($1, $2, NULL, $3, NULL) 
$$
