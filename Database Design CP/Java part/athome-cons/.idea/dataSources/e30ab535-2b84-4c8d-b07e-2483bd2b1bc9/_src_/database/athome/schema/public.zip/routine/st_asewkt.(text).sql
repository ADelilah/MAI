CREATE FUNCTION st_asewkt (text) RETURNS text
	LANGUAGE sql
AS $$
 SELECT public.ST_AsEWKT($1::public.geometry);  
$$
