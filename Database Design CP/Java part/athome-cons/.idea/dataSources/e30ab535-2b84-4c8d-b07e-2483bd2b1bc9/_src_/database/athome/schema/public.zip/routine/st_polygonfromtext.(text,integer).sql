CREATE FUNCTION st_polygonfromtext (text, integer) RETURNS geometry
	LANGUAGE sql
AS $$
SELECT public.ST_PolyFromText($1, $2)
$$
