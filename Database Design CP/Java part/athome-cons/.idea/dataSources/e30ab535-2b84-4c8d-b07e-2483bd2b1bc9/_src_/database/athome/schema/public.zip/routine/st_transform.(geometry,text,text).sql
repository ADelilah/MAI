CREATE FUNCTION st_transform (geom geometry, from_proj text, to_proj text) RETURNS geometry
	LANGUAGE sql
AS $$
SELECT postgis_transform_geometry($1, $2, $3, 0)
$$
