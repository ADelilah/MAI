CREATE FUNCTION st_histogram (rast raster, nband integer, bins integer, "right" boolean, OUT min double precision, OUT max double precision, OUT count bigint, OUT percent double precision) RETURNS SETOF record
	LANGUAGE sql
AS $$
 SELECT min, max, count, percent FROM public._ST_histogram($1, $2, TRUE, 1, $3, NULL, $4) 
$$
