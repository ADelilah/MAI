CREATE FUNCTION st_line_locate_point (geom1 geometry, geom2 geometry) RETURNS double precision
	LANGUAGE sql
AS $$
 SELECT public._postgis_deprecate('ST_Line_Locate_Point', 'ST_LineLocatePoint', '2.1.0');
     SELECT public.ST_LineLocatePoint($1, $2);
  
$$
