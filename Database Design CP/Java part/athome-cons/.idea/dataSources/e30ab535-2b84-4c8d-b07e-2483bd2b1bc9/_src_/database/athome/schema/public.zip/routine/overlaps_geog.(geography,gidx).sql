CREATE FUNCTION overlaps_geog (geography, gidx) RETURNS boolean
	LANGUAGE sql
AS $$
  SELECT $2 OPERATOR(public.&&) $1;
$$
