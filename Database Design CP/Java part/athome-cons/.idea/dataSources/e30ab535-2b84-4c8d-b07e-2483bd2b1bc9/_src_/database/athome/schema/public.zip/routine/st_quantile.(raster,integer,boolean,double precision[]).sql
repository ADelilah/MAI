CREATE FUNCTION st_quantile (rast raster, nband integer DEFAULT 1, exclude_nodata_value boolean DEFAULT true, quantiles double precision[] DEFAULT NULL::double precision[], OUT quantile double precision, OUT value double precision) RETURNS SETOF record
	LANGUAGE sql
AS $$
 SELECT public._ST_quantile($1, $2, $3, 1, $4) 
$$
