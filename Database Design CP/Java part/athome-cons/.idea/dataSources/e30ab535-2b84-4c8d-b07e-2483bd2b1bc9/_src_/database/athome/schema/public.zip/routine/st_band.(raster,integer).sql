CREATE FUNCTION st_band (rast raster, nband integer) RETURNS raster
	LANGUAGE sql
AS $$
 SELECT  public.ST_band($1, ARRAY[$2]) 
$$
