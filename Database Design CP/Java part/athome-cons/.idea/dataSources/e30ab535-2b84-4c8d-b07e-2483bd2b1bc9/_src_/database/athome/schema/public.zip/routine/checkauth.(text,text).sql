CREATE FUNCTION checkauth (text, text) RETURNS integer
	LANGUAGE sql
AS $$
 SELECT CheckAuth('', $1, $2) 
$$
