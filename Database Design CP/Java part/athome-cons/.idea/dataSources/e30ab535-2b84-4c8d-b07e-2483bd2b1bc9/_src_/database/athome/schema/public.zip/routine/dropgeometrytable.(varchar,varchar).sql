CREATE FUNCTION dropgeometrytable (schema_name character varying, table_name character varying) RETURNS text
	LANGUAGE sql
AS $$
 SELECT DropGeometryTable('',$1,$2) 
$$
