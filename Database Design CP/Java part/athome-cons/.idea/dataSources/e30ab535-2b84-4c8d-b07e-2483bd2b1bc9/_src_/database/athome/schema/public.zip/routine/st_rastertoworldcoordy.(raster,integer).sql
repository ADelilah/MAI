CREATE FUNCTION st_rastertoworldcoordy (rast raster, yr integer) RETURNS double precision
	LANGUAGE sql
AS $$
 SELECT latitude FROM public._ST_rastertoworldcoord($1, NULL, $2) 
$$
