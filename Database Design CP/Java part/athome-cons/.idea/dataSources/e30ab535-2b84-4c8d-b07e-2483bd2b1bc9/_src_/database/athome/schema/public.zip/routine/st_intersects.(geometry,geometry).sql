CREATE FUNCTION st_intersects (geom1 geometry, geom2 geometry) RETURNS boolean
	LANGUAGE sql
AS $$
SELECT $1 OPERATOR(public.&&) $2 AND public._ST_Intersects($1,$2)
$$
