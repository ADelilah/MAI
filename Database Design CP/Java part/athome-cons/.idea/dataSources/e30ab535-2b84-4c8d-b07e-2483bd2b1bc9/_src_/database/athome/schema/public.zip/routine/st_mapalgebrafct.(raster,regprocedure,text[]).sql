CREATE FUNCTION st_mapalgebrafct (rast raster, onerastuserfunc regprocedure, VARIADIC args text[]) RETURNS raster
	LANGUAGE sql
AS $$
 SELECT public.ST_mapalgebrafct($1, 1, NULL, $2, VARIADIC $3) 
$$
